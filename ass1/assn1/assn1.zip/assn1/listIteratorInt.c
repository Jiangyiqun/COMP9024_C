/*
  listIteratorInt.c : list Iterator ADT implementation
  Written by .... 
  Date: ....
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "listIteratorInt.h"

typedef struct Node {

  // implement struct here .. 

} Node;

typedef struct IteratorIntRep {

  // implement struct here .. 
  
} IteratorIntRep;



/*

  Your local functions here, if any.... 


 */



IteratorInt IteratorIntNew(){

  // implement this function 

  return NULL;  // you need to change this...
}

void reset(IteratorInt it){

  // implement this function 

}


int add(IteratorInt it, int v){
  
  // implement this function 
  
  return 0;  // you need to change this...
}


int hasNext(IteratorInt it){
  
  // implement this function 
  
  return 0;  // you need to change this...
}

int hasPrevious(IteratorInt it){
  
  // implement this function 
  
  return 0;  // you need to change this...
}


int *next(IteratorInt it){
  
  // implement this function 
  
  return NULL;  // you need to change this...
}

int *previous(IteratorInt it){

  // implement this function 
  
  return NULL;  // you need to change this...

}


int deleteElm(IteratorInt it){
  
  // implement this function 
  
  return 0;  // you need to change this...
}


int set(IteratorInt it, int v){
  
  // implement this function 

  return 0;
}

int *findNext(IteratorInt it, int v){

  // implement this function 
  
  return 0;
}

int *findPrevious(IteratorInt it, int v){
  
  // implement this function 
  
  return 0;
}

void freeIt(IteratorInt it){

  // implement this function 
  
  return;

}





